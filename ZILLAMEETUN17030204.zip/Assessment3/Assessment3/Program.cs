﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using BSTree;

namespace Assessment3
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            var csvData = new CsvData();
            csvData.ProcessFile("companies.csv");
            

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(csvData));

        }
    }

    public class CsvData
    {
        public string[] Headers { get; private set; }
        public List<Company> Companies { get; private set; }

        public void ProcessFile(string filename)
        {
            var csvLocation = Path.Combine(Directory.GetCurrentDirectory(), filename);

            //Console.Write(csvLocation);

            var file = GetAllRowsFromCsv(csvLocation);

            var headerRow = file[0];
            Headers = GetHeaders(headerRow);

            var companyRows = file.Skip(1);
            Companies = ProcessIntoCompanies(companyRows);
            foreach (var company in Companies)
            {
                company.calculateTradingPotential(Companies);
            }
        }

        private string[] GetAllRowsFromCsv(string csvLocation)
        {
            return File.ReadAllText(csvLocation).Split(new[] { Environment.NewLine }, StringSplitOptions.None);
        }

        private string[] GetHeaders(string firstRow)
        {
            return firstRow.Split(new[] { ',' }, StringSplitOptions.None);
        }

        private List<Company> ProcessIntoCompanies(IEnumerable<string> rows)
        {
            return rows.Where(r => string.IsNullOrWhiteSpace(r) == false).Select(r => new Company(r)).ToList();
        }
        
       
        
    }
}
