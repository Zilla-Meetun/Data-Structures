﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment3
{
    public interface ICompany
    {
        string Name { get; set; }
        int NetIncome { get; set; }
        int OpIncome { get; set; }
        int Assets { get; set; }
        int Employees { get; set; }
        int tradingPot { get; set; }
        List<string> Buyers { get; }
    }

    public class Company : IComparable<Company>, ICompany
    {
        public Company(string line)
        {
            string[] lineSplit = line.Split(new[] { ',' }, StringSplitOptions.None);
            Name = lineSplit[0];
            NetIncome = Convert.ToInt32(lineSplit[1]);
            OpIncome = Convert.ToInt32(lineSplit[2]);
            Assets = Convert.ToInt32(lineSplit[3]);
            Employees = Convert.ToInt32(lineSplit[4]);
            lineSplit[5] = lineSplit[5].Trim(new char[] { '[', ']' });
            Buyers = (lineSplit[5]).Split(new[] { ';' }, StringSplitOptions.None).ToList();
        }

       

        public void calculateTradingPotential(List<Company> companies)
        {
            tradingPot = NetIncome;
            //Console.Write(Name+"  ");
            foreach (var company in companies)
            {
                
                if (company.Buyers.Contains(this.Name))
                {
                    tradingPot += company.NetIncome;
                    //Console.Write(company.Name+";"+company.NetIncome+ "  ");
                    continue; //Prevents a company form being added twice as a trading partner
                    
                }
                if (this.Buyers.Contains(company.Name))
                {
                    tradingPot += company.NetIncome;
                    //Console.Write(company.Name+";"+company.NetIncome+"  ");
                }
                
            }
            //Console.WriteLine("  pot: " + tradingPot);

        }

        public string Name { get; set; }

        public int NetIncome { get; set; }

        public int OpIncome { get; set; }

        public int Assets { get; set; }

        public int Employees { get; set; }

        public int tradingPot { get; set; }

        public List<string> Buyers { get; private set; }


        public int CompareTo(Company obj)
        {
            if (obj == null)
                return 1;

            return string.Compare(Name, obj.Name);
        }
    }

}
