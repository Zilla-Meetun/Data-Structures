﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BSTree;

namespace Assessment3
{
    public partial class Form1 : Form
    {
        CsvData data;
        AVLTree<string> nameTree = new AVLTree<string>();
        
        Company biggestPot;
        //AVLTree<Company> companyTree = new AVLTree<Company>();
        int column = 1;

        

        public Form1(CsvData csvData)
        {
            InitializeComponent();

            data = csvData;

            SortCompanies();
            getLargestTradingPot();
            mostTradingPot.Text = biggestPot.Name + " has the largest\ntrading potential of " + biggestPot.tradingPot;
        }

        private void SortCompanies()
        {
            Title.Items.Clear();
            

            
            nameLabel.Text = "company : " + data.Headers[column]+" (Info)";

            string buf1 = null;
            string[] buf2;
            nameTree = new AVLTree<string>();
            foreach (var company in data.Companies)
            {
                nameTree.InsertItem(company.Name);

            }
            var maxSearches = nameTree.Height();
            var numberOfCompanies = nameTree.Count();
            height.Text = $"Max Searches: {maxSearches}";
            count.Text = $"No. Companies: {numberOfCompanies}";

            nameTree.InOrder(ref buf1);
            buf2 = buf1.Split(new[] { '|' }, StringSplitOptions.None);
            
            for (int i = 0; i < buf2.Length - 1; i++)
            {
                for (int x = 0; x < data.Companies.Count() - 1; x++)
                {
                    if (buf2[i].CompareTo(data.Companies[x].Name) == 0)
                    {

                        switch (column)
                        {
                            case 1:
                                if (data.Companies[x].NetIncome != 0)
                                    Title.Items.Add(data.Companies[x].Name + " :  " + data.Companies[x].NetIncome);
                                else
                                    Title.Items.Add(data.Companies[x].Name + " :  " + '-');
                                break;
                            case 2:
                                if (data.Companies[x].OpIncome != 0)
                                    Title.Items.Add(data.Companies[x].Name + " :  " + data.Companies[x].OpIncome);
                                else
                                    Title.Items.Add(data.Companies[x].Name + " :  " + '-');
                                break;
                            case 3:
                                if (data.Companies[x].Assets != 0)
                                    Title.Items.Add(data.Companies[x].Name + " :  " + data.Companies[x].Assets);
                                else
                                    Title.Items.Add(data.Companies[x].Name + " :  " + '-');
                                break;
                            case 4:
                                if (data.Companies[x].Employees != 0)
                                    Title.Items.Add(data.Companies[x].Name + " :  " + data.Companies[x].Employees);
                                else
                                    Title.Items.Add(data.Companies[x].Name + " :  " + '-');
                                break;
                            case 5:
                                //takes the string list of buyers and turns into a single string
                                string temp = "";
                                for (int a = 0; a < data.Companies[x].Buyers.Count; a++)
                                {
                                    temp += data.Companies[x].Buyers[a].ToString() + " | ";
                                }
                                Title.Items.Add(data.Companies[x].Name + " :  " + temp);
                                break;
                        }
                        //once the item is found, ends loop
                        break;
                    }
                }
            }
            
        }


        private void showNet_Click(object sender, EventArgs e)
        {
            //NetIncome
            column = 1;
            SortCompanies();
        }

        private void showOp_Click(object sender, EventArgs e)
        {
            //OpIncome
            column = 2;
            SortCompanies();
        }

        private void showAssets_Click(object sender, EventArgs e)
        {
            //Assets
            column = 3;
            SortCompanies();
        }

        private void showEmploy_Click(object sender, EventArgs e)
        {
            //Employees
            column = 4;
            SortCompanies();
        }

        private void showBuyer_Click(object sender, EventArgs e)
        {
            //Buyers
            column = 5;
            SortCompanies();
            
            
        }



        //empty-
        private void infoLable_Click(object sender, EventArgs e)
        {

        }

        private void confirmBttn_Click(object sender, EventArgs e)
        {
            errorLable.Text = (!nameOpt.Checked && !infoOpt.Checked) ? "Please select an option!" : "";
            if (!listSelect.Visible)
                errorLable.Text = "";
            errorLabel1.ForeColor = Color.Red;
            errorLabel1.Text = (!editOpt.Checked && !delOpt.Checked && !searchOpt.Checked) ? "Please select an action" : "";

            var weAreDeletingTheCompany = (delOpt.Checked && nameOpt.Checked);
            var weAreDeletingAValue = (delOpt.Checked && infoOpt.Checked);
            var weAreEditingAValue = (editOpt.Checked && infoOpt.Checked);
            var buyerOrNetChanged = false;

            int saveIndex = Title.SelectedIndex;

            List<string> removedSeller =null;
            
            int CompanyIndex;

            if (weAreDeletingAValue || weAreDeletingAValue || weAreDeletingTheCompany)
                CompanyIndex = findCompanyIndex();

            if (editOpt.Checked && nameOpt.Checked)
            {
                MessageBox.Show("Cannot Edit Company Name");
            }

            errorLable2.Text = "";
            if (weAreEditingAValue)
            {
                CompanyIndex = findCompanyIndex();
               
                if (Title.SelectedIndex == -1)
                    errorLable2.Text = "Please select the line to edit";
                else if (nameLabel.Text.Contains(data.Headers[5]))
                {
                    if (int.TryParse(changeValue.Text, out int newValue) && changeValue.Text != "")
                        errorLable2.Text = "Please Enter Text to Edit a Buyer";
                    else
                        if (buyerList.SelectedIndex != -1)
                    {
                        data.Companies[CompanyIndex].Buyers[buyerList.SelectedIndex] = changeValue.Text;
                        buyerList.Items.Clear();
                        foreach (var buyer in data.Companies[CompanyIndex].Buyers)
                            buyerList.Items.Add(buyer);
                         buyerOrNetChanged = true;
                    }
                    else
                        errorLable2.Text = "please select the lines to edit";
                }
                else
                {
                    // editing a number
                    if (int.TryParse(changeValue.Text, out int newValue) && changeValue.Text != "")
                    {
                        switch (column)
                        {
                            case 1:
                                data.Companies[CompanyIndex].NetIncome = Convert.ToInt32(changeValue.Text);
                                buyerOrNetChanged = true;
                                break;
                            case 2:
                                data.Companies[CompanyIndex].OpIncome = Convert.ToInt32(changeValue.Text);
                                break;
                            case 3:
                                data.Companies[CompanyIndex].Assets = Convert.ToInt32(changeValue.Text);
                                break;
                            case 4:
                                data.Companies[CompanyIndex].Employees = Convert.ToInt32(changeValue.Text);
                                break;
                        }

                    }
                    else
                    {
                        errorLable2.Text = "Please enter a intger Value";
                    }
                }
            }

            if (weAreDeletingTheCompany)
            {
                errorLable2.Text = "";
                if (Title.SelectedIndex == -1)
                    errorLable2.Text = "select the line you want to delete from";
                else
                {
                    foreach (var company in data.Companies)
                    {
                        if (Title.SelectedItem.ToString().Contains(company.Name))
                        {
                            if (MessageBox.Show("This will delete the entire company. \nAre you sure you want to continue?", "Delete Company", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                buyerOrNetChanged = true;
                                removedSeller = company.Buyers;
                                data.Companies.Remove(company);
                            }
                            break;
                        }


                    }

                }
            }

            if (weAreDeletingAValue)
            {
                CompanyIndex = findCompanyIndex();
                if (Title.SelectedIndex == -1)
                    errorLable2.Text = "select the line you want to delete from";
                else
                {
                    switch (column)
                    {
                        case 1:
                            data.Companies[CompanyIndex].NetIncome = 0;
                            buyerOrNetChanged = true;
                            break;
                        case 2:
                            data.Companies[CompanyIndex].OpIncome = 0;
                            break;
                        case 3:
                            data.Companies[CompanyIndex].Assets = 0;
                            break;
                        case 4:
                            data.Companies[CompanyIndex].Employees = 0;
                            break;
                        case 5:
                            if (buyerList.SelectedIndex == -1)
                                errorLable2.Text = "please select the buyer you want to delete";
                            else
                            {
                                buyerOrNetChanged = true;
                                data.Companies[CompanyIndex].Buyers.RemoveAt(buyerList.SelectedIndex);
                                buyerList.Items.Clear();
                                foreach (var buyer in data.Companies[CompanyIndex].Buyers)
                                    buyerList.Items.Add(buyer);
                            }
                            break;
                    }
                }
            }

            if (buyerOrNetChanged)
            {
                CompanyIndex = findCompanyIndex();
                foreach (var company in data.Companies)
                {
                    
                    if (Title.SelectedItem.ToString().Substring(0, 3).Equals(company.Name)||company.Buyers.Contains(Title.SelectedItem.ToString().Substring(0, 3)))
                    {
                        company.calculateTradingPotential(data.Companies);
                        //Console.WriteLine("buyer or net changed for "+ company.Name);
                        
                        
                        getLargestTradingPot();
                        mostTradingPot.Text = biggestPot.Name + " has the largest\ntrading potential of " + biggestPot.tradingPot;
                    }
                    else if (CompanyIndex!=-1)
                    {
                            if (data.Companies[CompanyIndex].Buyers.Contains(company.Name))
                            {
                                company.calculateTradingPotential(data.Companies);
                                getLargestTradingPot();
                                mostTradingPot.Text = biggestPot.Name + " has the largest\ntrading potential of " + biggestPot.tradingPot;
                            }
                    }
                    else if (removedSeller.Contains(company.Name))
                        {
                            company.calculateTradingPotential(data.Companies);
                            getLargestTradingPot();
                            mostTradingPot.Text = biggestPot.Name + " has the largest\ntrading potential of " + biggestPot.tradingPot;
                        }
                       
                        
                }
            }

            if (searchOpt.Checked)
            {
                errorLable2.Text = "";
                if (changeValue.Text == "")
                    errorLable2.Text = "enter something to search";
                else
                {
                    Title.Items.Clear();
                    errorLabel1.ForeColor = Color.Blue;
                    errorLabel1.Text = "click on a company to see its attributes";
                    foreach (var company in data.Companies)
                    {
                        if (company.Name.Contains(changeValue.Text))
                        {
                            Title.Items.Add(company.Name);
                        }
                    }


                }
            }
            else
            {
                SortCompanies();

                Title.SelectedIndex = saveIndex;
            }
        }

        public void getLargestTradingPot()
        {
            biggestPot = data.Companies.ElementAt(0);
            foreach (var company in data.Companies)
            {
                if (company.tradingPot > biggestPot.tradingPot)
                    biggestPot = company;
            }
            
        }


        private void delOpt_CheckedChanged(object sender, EventArgs e)
        {
            if (delOpt.Checked)
            {
                changeValue.Text = "";
            }
        }

        private void Title_SelectedIndexChanged(object sender, EventArgs e)
        {
            buyerList.Items.Clear();
            int companyIndex = findCompanyIndex();
            if (searchOpt.Checked)
            {
                
                if (companyIndex != -1)
                {
                    buyerList.Items.Add("Net Income: " + data.Companies[companyIndex].NetIncome);
                    buyerList.Items.Add("Operation Income: " + data.Companies[companyIndex].OpIncome);
                    buyerList.Items.Add("Assets: " + data.Companies[companyIndex].Assets);
                    buyerList.Items.Add("Employees: " + data.Companies[companyIndex].Employees);
                    for (int a = 0; a < data.Companies[companyIndex].Buyers.Count; a++)
                        buyerList.Items.Add("Buyer" + (a + 1) + ": " + data.Companies[companyIndex].Buyers[a]);
                    buyerList.Items.Add("Trade Potential: " + data.Companies[companyIndex].tradingPot);


                }

            }
             
            else if (companyIndex != -1 && column ==5)
            {
                foreach (var buyer in data.Companies[companyIndex].Buyers)
                    buyerList.Items.Add(buyer);
            }
           
          
                
        }

        private int findCompanyIndex()
        {
            if (Title.SelectedIndex!=-1)
                for (int i = 0; i<data.Companies.Count; i++)
                {
                    if (Title.SelectedItem.ToString().Substring(0, 3).Contains(data.Companies[i].Name))
                        return i;

                }
            
            return -1;
        }

        private void searchOpt_CheckedChanged(object sender, EventArgs e)
        {
            if (searchOpt.Checked)
            {
                listSelect.Visible = false;
                errorLable.Text = "";
                
            }
            else
            {
                listSelect.Visible = true;
                buyerList.Items.Clear();
                errorLabel1.Text = "";
            }
               
        }

        private void editOpt_CheckedChanged(object sender, EventArgs e)
        {
            if (editOpt.Checked)
                infoOpt.Checked = true;
        }
    }
}
