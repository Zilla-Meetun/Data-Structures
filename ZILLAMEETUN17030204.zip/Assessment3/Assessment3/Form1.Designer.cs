﻿namespace Assessment3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.ListBox();
            this.SortByBttns = new System.Windows.Forms.GroupBox();
            this.showAssets = new System.Windows.Forms.Button();
            this.showNet = new System.Windows.Forms.Button();
            this.showBuyer = new System.Windows.Forms.Button();
            this.showEmploy = new System.Windows.Forms.Button();
            this.showOp = new System.Windows.Forms.Button();
            this.actionSelect = new System.Windows.Forms.GroupBox();
            this.searchOpt = new System.Windows.Forms.RadioButton();
            this.delOpt = new System.Windows.Forms.RadioButton();
            this.editOpt = new System.Windows.Forms.RadioButton();
            this.changeValue = new System.Windows.Forms.TextBox();
            this.confirmBttn = new System.Windows.Forms.Button();
            this.nameLabel = new System.Windows.Forms.Label();
            this.errorLable = new System.Windows.Forms.Label();
            this.errorLabel1 = new System.Windows.Forms.Label();
            this.errorLabel3 = new System.Windows.Forms.Label();
            this.errorLable2 = new System.Windows.Forms.Label();
            this.count = new System.Windows.Forms.Label();
            this.height = new System.Windows.Forms.Label();
            this.nameOpt = new System.Windows.Forms.RadioButton();
            this.infoOpt = new System.Windows.Forms.RadioButton();
            this.listSelect = new System.Windows.Forms.GroupBox();
            this.buyerList = new System.Windows.Forms.ListBox();
            this.mostTradingPot = new System.Windows.Forms.Label();
            this.SortByBttns.SuspendLayout();
            this.actionSelect.SuspendLayout();
            this.listSelect.SuspendLayout();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.FormattingEnabled = true;
            this.Title.Location = new System.Drawing.Point(110, 36);
            this.Title.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(279, 277);
            this.Title.TabIndex = 0;
            this.Title.SelectedIndexChanged += new System.EventHandler(this.Title_SelectedIndexChanged);
            // 
            // SortByBttns
            // 
            this.SortByBttns.Controls.Add(this.showAssets);
            this.SortByBttns.Controls.Add(this.showNet);
            this.SortByBttns.Controls.Add(this.showBuyer);
            this.SortByBttns.Controls.Add(this.showEmploy);
            this.SortByBttns.Controls.Add(this.showOp);
            this.SortByBttns.Location = new System.Drawing.Point(12, 29);
            this.SortByBttns.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.SortByBttns.Name = "SortByBttns";
            this.SortByBttns.Padding = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.SortByBttns.Size = new System.Drawing.Size(81, 297);
            this.SortByBttns.TabIndex = 2;
            this.SortByBttns.TabStop = false;
            this.SortByBttns.Text = "Attribute Selection";
            // 
            // showAssets
            // 
            this.showAssets.Location = new System.Drawing.Point(0, 135);
            this.showAssets.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.showAssets.Name = "showAssets";
            this.showAssets.Size = new System.Drawing.Size(80, 47);
            this.showAssets.TabIndex = 9;
            this.showAssets.Text = "Total Assets";
            this.showAssets.UseVisualStyleBackColor = true;
            this.showAssets.Click += new System.EventHandler(this.showAssets_Click);
            // 
            // showNet
            // 
            this.showNet.Location = new System.Drawing.Point(-1, 26);
            this.showNet.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.showNet.Name = "showNet";
            this.showNet.Size = new System.Drawing.Size(80, 47);
            this.showNet.TabIndex = 8;
            this.showNet.Text = "Net Income";
            this.showNet.UseVisualStyleBackColor = true;
            this.showNet.Click += new System.EventHandler(this.showNet_Click);
            // 
            // showBuyer
            // 
            this.showBuyer.Location = new System.Drawing.Point(0, 250);
            this.showBuyer.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.showBuyer.Name = "showBuyer";
            this.showBuyer.Size = new System.Drawing.Size(80, 47);
            this.showBuyer.TabIndex = 7;
            this.showBuyer.Text = "Buyers";
            this.showBuyer.UseVisualStyleBackColor = true;
            this.showBuyer.Click += new System.EventHandler(this.showBuyer_Click);
            // 
            // showEmploy
            // 
            this.showEmploy.Location = new System.Drawing.Point(1, 192);
            this.showEmploy.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.showEmploy.Name = "showEmploy";
            this.showEmploy.Size = new System.Drawing.Size(80, 47);
            this.showEmploy.TabIndex = 6;
            this.showEmploy.Text = "No. Employees";
            this.showEmploy.UseVisualStyleBackColor = true;
            this.showEmploy.Click += new System.EventHandler(this.showEmploy_Click);
            // 
            // showOp
            // 
            this.showOp.Location = new System.Drawing.Point(-1, 80);
            this.showOp.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.showOp.Name = "showOp";
            this.showOp.Size = new System.Drawing.Size(80, 47);
            this.showOp.TabIndex = 5;
            this.showOp.Text = "Operation Income";
            this.showOp.UseVisualStyleBackColor = true;
            this.showOp.Click += new System.EventHandler(this.showOp_Click);
            // 
            // actionSelect
            // 
            this.actionSelect.Controls.Add(this.searchOpt);
            this.actionSelect.Controls.Add(this.delOpt);
            this.actionSelect.Controls.Add(this.editOpt);
            this.actionSelect.Location = new System.Drawing.Point(401, 57);
            this.actionSelect.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.actionSelect.Name = "actionSelect";
            this.actionSelect.Padding = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.actionSelect.Size = new System.Drawing.Size(102, 118);
            this.actionSelect.TabIndex = 4;
            this.actionSelect.TabStop = false;
            this.actionSelect.Text = "Action";
            // 
            // searchOpt
            // 
            this.searchOpt.AutoSize = true;
            this.searchOpt.Location = new System.Drawing.Point(6, 72);
            this.searchOpt.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.searchOpt.Name = "searchOpt";
            this.searchOpt.Size = new System.Drawing.Size(57, 17);
            this.searchOpt.TabIndex = 3;
            this.searchOpt.TabStop = true;
            this.searchOpt.Text = "search";
            this.searchOpt.UseVisualStyleBackColor = true;
            this.searchOpt.CheckedChanged += new System.EventHandler(this.searchOpt_CheckedChanged);
            // 
            // delOpt
            // 
            this.delOpt.AutoSize = true;
            this.delOpt.Location = new System.Drawing.Point(6, 48);
            this.delOpt.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.delOpt.Name = "delOpt";
            this.delOpt.Size = new System.Drawing.Size(56, 17);
            this.delOpt.TabIndex = 1;
            this.delOpt.TabStop = true;
            this.delOpt.Text = "Delete";
            this.delOpt.UseVisualStyleBackColor = true;
            this.delOpt.CheckedChanged += new System.EventHandler(this.delOpt_CheckedChanged);
            // 
            // editOpt
            // 
            this.editOpt.AutoSize = true;
            this.editOpt.Location = new System.Drawing.Point(6, 25);
            this.editOpt.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.editOpt.Name = "editOpt";
            this.editOpt.Size = new System.Drawing.Size(43, 17);
            this.editOpt.TabIndex = 0;
            this.editOpt.TabStop = true;
            this.editOpt.Text = "Edit";
            this.editOpt.UseVisualStyleBackColor = true;
            this.editOpt.CheckedChanged += new System.EventHandler(this.editOpt_CheckedChanged);
            // 
            // changeValue
            // 
            this.changeValue.Location = new System.Drawing.Point(305, 322);
            this.changeValue.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.changeValue.Name = "changeValue";
            this.changeValue.Size = new System.Drawing.Size(89, 20);
            this.changeValue.TabIndex = 7;
            // 
            // confirmBttn
            // 
            this.confirmBttn.Location = new System.Drawing.Point(410, 304);
            this.confirmBttn.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.confirmBttn.Name = "confirmBttn";
            this.confirmBttn.Size = new System.Drawing.Size(71, 31);
            this.confirmBttn.TabIndex = 8;
            this.confirmBttn.Text = "Enter";
            this.confirmBttn.UseVisualStyleBackColor = true;
            this.confirmBttn.Click += new System.EventHandler(this.confirmBttn_Click);
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(110, 20);
            this.nameLabel.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(51, 13);
            this.nameLabel.TabIndex = 9;
            this.nameLabel.Text = "Company";
            // 
            // errorLable
            // 
            this.errorLable.AutoSize = true;
            this.errorLable.ForeColor = System.Drawing.Color.Red;
            this.errorLable.Location = new System.Drawing.Point(405, 267);
            this.errorLable.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.errorLable.Name = "errorLable";
            this.errorLable.Size = new System.Drawing.Size(0, 13);
            this.errorLable.TabIndex = 11;
            // 
            // errorLabel1
            // 
            this.errorLabel1.AutoSize = true;
            this.errorLabel1.ForeColor = System.Drawing.Color.Red;
            this.errorLabel1.Location = new System.Drawing.Point(408, 29);
            this.errorLabel1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.errorLabel1.Name = "errorLabel1";
            this.errorLabel1.Size = new System.Drawing.Size(0, 13);
            this.errorLabel1.TabIndex = 12;
            // 
            // errorLabel3
            // 
            this.errorLabel3.AutoSize = true;
            this.errorLabel3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.errorLabel3.ForeColor = System.Drawing.Color.Red;
            this.errorLabel3.Location = new System.Drawing.Point(102, 306);
            this.errorLabel3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.errorLabel3.Name = "errorLabel3";
            this.errorLabel3.Size = new System.Drawing.Size(0, 13);
            this.errorLabel3.TabIndex = 14;
            // 
            // errorLable2
            // 
            this.errorLable2.AutoSize = true;
            this.errorLable2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.errorLable2.ForeColor = System.Drawing.Color.Red;
            this.errorLable2.Location = new System.Drawing.Point(108, 325);
            this.errorLable2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.errorLable2.Name = "errorLable2";
            this.errorLable2.Size = new System.Drawing.Size(0, 13);
            this.errorLable2.TabIndex = 15;
            // 
            // count
            // 
            this.count.AutoSize = true;
            this.count.Location = new System.Drawing.Point(520, 57);
            this.count.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.count.Name = "count";
            this.count.Size = new System.Drawing.Size(103, 13);
            this.count.TabIndex = 16;
            this.count.Text = "No. Companies: INT";
            // 
            // height
            // 
            this.height.AutoSize = true;
            this.height.Location = new System.Drawing.Point(520, 78);
            this.height.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(99, 13);
            this.height.TabIndex = 17;
            this.height.Text = "Max Searches: INT";
            // 
            // nameOpt
            // 
            this.nameOpt.AutoSize = true;
            this.nameOpt.Location = new System.Drawing.Point(6, 25);
            this.nameOpt.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.nameOpt.Name = "nameOpt";
            this.nameOpt.Size = new System.Drawing.Size(69, 17);
            this.nameOpt.TabIndex = 0;
            this.nameOpt.TabStop = true;
            this.nameOpt.Text = "Company";
            this.nameOpt.UseVisualStyleBackColor = true;
            // 
            // infoOpt
            // 
            this.infoOpt.AutoSize = true;
            this.infoOpt.Location = new System.Drawing.Point(6, 48);
            this.infoOpt.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.infoOpt.Name = "infoOpt";
            this.infoOpt.Size = new System.Drawing.Size(90, 17);
            this.infoOpt.TabIndex = 1;
            this.infoOpt.TabStop = true;
            this.infoOpt.Text = "Company Info";
            this.infoOpt.UseVisualStyleBackColor = true;
            // 
            // listSelect
            // 
            this.listSelect.Controls.Add(this.infoOpt);
            this.listSelect.Controls.Add(this.nameOpt);
            this.listSelect.Location = new System.Drawing.Point(401, 188);
            this.listSelect.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.listSelect.Name = "listSelect";
            this.listSelect.Padding = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.listSelect.Size = new System.Drawing.Size(102, 72);
            this.listSelect.TabIndex = 5;
            this.listSelect.TabStop = false;
            this.listSelect.Text = "To act on";
            // 
            // buyerList
            // 
            this.buyerList.FormattingEnabled = true;
            this.buyerList.Location = new System.Drawing.Point(518, 97);
            this.buyerList.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.buyerList.Name = "buyerList";
            this.buyerList.Size = new System.Drawing.Size(130, 173);
            this.buyerList.TabIndex = 18;
            // 
            // mostTradingPot
            // 
            this.mostTradingPot.AutoSize = true;
            this.mostTradingPot.Location = new System.Drawing.Point(512, 306);
            this.mostTradingPot.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.mostTradingPot.Name = "mostTradingPot";
            this.mostTradingPot.Size = new System.Drawing.Size(35, 13);
            this.mostTradingPot.TabIndex = 19;
            this.mostTradingPot.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 354);
            this.Controls.Add(this.mostTradingPot);
            this.Controls.Add(this.buyerList);
            this.Controls.Add(this.height);
            this.Controls.Add(this.count);
            this.Controls.Add(this.errorLable2);
            this.Controls.Add(this.errorLabel3);
            this.Controls.Add(this.errorLabel1);
            this.Controls.Add(this.errorLable);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.confirmBttn);
            this.Controls.Add(this.changeValue);
            this.Controls.Add(this.listSelect);
            this.Controls.Add(this.actionSelect);
            this.Controls.Add(this.SortByBttns);
            this.Controls.Add(this.Title);
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "Form1";
            this.Text = "Assessment DS&A";
            this.SortByBttns.ResumeLayout(false);
            this.actionSelect.ResumeLayout(false);
            this.actionSelect.PerformLayout();
            this.listSelect.ResumeLayout(false);
            this.listSelect.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Title;
        private System.Windows.Forms.GroupBox SortByBttns;
        private System.Windows.Forms.Button showBuyer;
        private System.Windows.Forms.Button showEmploy;
        private System.Windows.Forms.Button showOp;
        private System.Windows.Forms.Button showNet;
        private System.Windows.Forms.GroupBox actionSelect;
        private System.Windows.Forms.RadioButton delOpt;
        private System.Windows.Forms.RadioButton editOpt;
        private System.Windows.Forms.TextBox changeValue;
        private System.Windows.Forms.Button confirmBttn;
        private System.Windows.Forms.Button showAssets;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label errorLable;
        private System.Windows.Forms.Label errorLabel1;
        private System.Windows.Forms.Label errorLabel3;
        private System.Windows.Forms.Label errorLable2;
        private System.Windows.Forms.Label count;
        private System.Windows.Forms.Label height;
        private System.Windows.Forms.RadioButton nameOpt;
        private System.Windows.Forms.RadioButton infoOpt;
        private System.Windows.Forms.GroupBox listSelect;
        private System.Windows.Forms.ListBox buyerList;
        private System.Windows.Forms.RadioButton searchOpt;
        private System.Windows.Forms.Label mostTradingPot;
    }
}

